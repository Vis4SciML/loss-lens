# Back-End Operations Instructions
This is an instruction to introduce all the operation functions in the whole pipeline. Currently under development.

## Model Euclidean Distance Similarity
Model Euclidean Distance Similarity is defined in the `calculate_model_euclidean_distance_similarity` under `functions.py` in the current folder.

```python
def calculate_model_euclidean_distance_similarity(dataset, subdataset_list, IN_DIM, OUT_DIM):
    # load all the models
    model_list = []
    for subdataset in subdataset_list:
        model_path = '../model/' + dataset + '/' + subdataset + '/model_final.pt'
        this_model = MLPSmall(IN_DIM, OUT_DIM)
        this_model.load_state_dict(torch.load(model_path))
        this_model.eval()
        model_list.append(this_model)

    # join the tensors of all subdatasets
    modelTensor_list = []
    for model in model_list:
        modelTensor_list.append(torch.cat((model.linear_1.weight.data.reshape(-1),model.linear_2.weight.data.reshape(-1))))
    
    # calculate the euclidean distance between models
    euclidean_distance_column = []
    for i in range(len(model_list)):
        euclidean_distance_row = []
        for j in range(len(model_list)):
            euclidean_distance_row.append((modelTensor_list[i] - modelTensor_list[j]).pow(2).sum().sqrt())
        euclidean_distance_column.append(euclidean_distance_row)

    # generate the distance matrix
    euclidean_distance_matrix = np.array(euclidean_distance_column)
    
    # calculate the MDS of the euclidean distance matrix for models similarity
    embedding = MDS(n_components=2,dissimilarity='precomputed')
    X_transformed = embedding.fit_transform(euclidean_distance_matrix)
    
    return X_transformed
```

## Model CKA Similarity
Model CKA Similarity is defined in the `calculate_model_cka_similarity` under `functions.py` in the current folder.

```python
def calculate_model_cka_similarity(dataset, subdataset_list, IN_DIM, OUT_DIM, reshape_x, reshape_y):
    # load all the models
    model_list = []
    for subdataset in subdataset_list:
        model_path = '../model/' + dataset + '/' + subdataset + '/model_final.pt'
        this_model = MLPSmall(IN_DIM, OUT_DIM)
        this_model.load_state_dict(torch.load(model_path))
        this_model.eval()
        model_list.append(this_model)

    # join the tensors of all subdatasets
    modelTensor_list = []
    for model in model_list:
        modelTensor_list.append(torch.cat((model.linear_1.weight.data.reshape(-1),model.linear_2.weight.data.reshape(-1))))
    
    # initialize the CKA class
    np_cka = CKA()
    
    # calculate the linear CKA similarity between models
    linear_cka_similarity_column = []
    pbar = tqdm(model_list)
    for k in pbar:
        i = model_list.index(k)
        linear_cka_similarity_row = []
        for j in range(len(model_list)):
            linear_cka_similarity_row.append(np_cka.linear_CKA(modelTensor_list[i].numpy().reshape((reshape_x, reshape_y)), modelTensor_list[j].numpy().reshape((reshape_x, reshape_y))))
        linear_cka_similarity_column.append(linear_cka_similarity_row)
    
    kernel_cka_similarity_column = []
    pbar = tqdm(model_list)
    for k in pbar:
        i = model_list.index(k)
        kernel_cka_similarity_row = []
        for j in range(len(model_list)):
            kernel_cka_similarity_row.append(np_cka.kernel_CKA(modelTensor_list[i].numpy().reshape((reshape_x, reshape_y)), modelTensor_list[j].numpy().reshape((reshape_x, reshape_y))))
        kernel_cka_similarity_column.append(kernel_cka_similarity_row)
    
    # generate the distance matrix for linear CKA
    linear_cka_matrix = np.array(linear_cka_similarity_column)
    
    # generate the distance matrix for RBF kernel CKA
    kernel_cka_matrix = np.array(kernel_cka_similarity_column)
    
    # calculate the MDS of the linear CKA distance matrix for models similarity
    linear_cka_mds = MDS(n_components=2, dissimilarity='precomputed')
    linear_cka_embedding = linear_cka_mds.fit_transform(linear_cka_matrix)
    
    # calculate the MDS of the RBF kernel CKA distance matrix for models similarity
    kernel_cka_mds = MDS(n_components=2, dissimilarity='precomputed')
    kernel_cka_embedding = kernel_cka_mds.fit_transform(kernel_cka_matrix)

    return linear_cka_embedding, kernel_cka_embedding
```

## Layer Euclidean Distance Similarity
Layer Euclidean Distance Similarity is defined in the `calculate_layer_euclidean_distance_similarity` under `functions.py` in the current folder.

```python
def calculate_layer_euclidean_distance_similarity(dataset, subdataset_list, IN_DIM, OUT_DIM, numLayers):
    # load all the models
    model_list = []
    for subdataset in subdataset_list:
        model_path = '../model/' + dataset + '/' + subdataset + '/model_final.pt'
        this_model = MLPSmall(IN_DIM, OUT_DIM)
        this_model.load_state_dict(torch.load(model_path))
        this_model.eval()
        model_list.append(this_model)
    
    # get the layer weights of all models
    layerOne_list = []
    layerTwo_list = []
    for model in model_list:
        layerOne_list.append(model.linear_1.weight.data)
        layerTwo_list.append(model.linear_2.weight.data)
    
    # calculate the euclidean distance for the first layer
    euclidean_distance_column_layerOne = []
    for i in range(len(layerOne_list)):
        euclidean_distance_row_layerOne = []
        for j in range(len(layerOne_list)):
            euclidean_distance_row_layerOne.append((layerOne_list[i] - layerOne_list[j]).pow(2).sum().sqrt())
        euclidean_distance_column_layerOne.append(euclidean_distance_row_layerOne)
    
    # generate the distance matrix
    euclidean_distance_matrix_layerOne = np.array(euclidean_distance_column_layerOne)
    
    # calculate the euclidean distance for the second layer
    euclidean_distance_column_layerTwo = []
    for i in range(len(layerTwo_list)):
        euclidean_distance_row_layerTwo = []
        for j in range(len(layerTwo_list)):
            euclidean_distance_row_layerTwo.append((layerTwo_list[i] - layerTwo_list[j]).pow(2).sum().sqrt())
        euclidean_distance_column_layerTwo.append(euclidean_distance_row_layerTwo)
    
    # generate the distance matrix
    euclidean_distance_matrix_layerTwo = np.array(euclidean_distance_column_layerTwo)
    
    # calculate the MDS of the euclidean distance matrix for layers similarity
    embedding_layerOne = MDS(n_components=1,dissimilarity='precomputed')
    X_transformed_layerOne = embedding_layerOne.fit_transform(euclidean_distance_matrix_layerOne)
    embedding_layerTwo = MDS(n_components=1,dissimilarity='precomputed')
    X_transformed_layerTwo = embedding_layerTwo.fit_transform(euclidean_distance_matrix_layerTwo)
    
    return X_transformed_layerOne, X_transformed_layerTwo
```

## Hessian Parametric Loss Landscapes with Related Model Information
Hessian Parametric Loss Landscapes with Related Model Information is defined in the `calculate_hessian_loss_landscape` under `functions.py` in the current folder.

```python
def calculate_hessian_loss_landscape(dataset, subdataset_list, i, criterion, x, y, IN_DIM, OUT_DIM, STEPS, START, END):
    # load all the models
    model_list = []
    for subdataset in subdataset_list:
        model_path = '../model/' + dataset + '/' + subdataset + '/model_final.pt'
        this_model = MLPSmall(IN_DIM, OUT_DIM)
        this_model.load_state_dict(torch.load(model_path))
        this_model.eval()
        model_list.append(this_model)

    model = model_list[i]
    model_perb = copy.deepcopy(model)

    # store the accuracy, recall, precision, f1 score, confusion matrix
    model_accuracy = []
    model_recall = []
    model_precision = []
    model_f1 = []
    model_confusionMatrix = []

    # calculate hessian contour and save model information
    hessian_comp = hessian(model, criterion, data=(x, y), cuda=False)
    top_eigenvalues, top_eigenvector = hessian_comp.eigenvalues(top_n=2)
    lams = np.linspace(START, END, STEPS).astype(np.float32)
    loss_list = []
    model_list = []
    for lam in lams:
        model_perb_fir = get_params(model, model_perb, top_eigenvector[0], lam)
        loss_list_sec = []
        model_list_sec = []
        for lam_sec in lams:
            model_perb_sec = copy.deepcopy(model_perb_fir)
            model_perb_sec = get_params(model_perb_fir, model_perb_sec, top_eigenvector[1], lam_sec)
            loss_list_sec.append(criterion(model_perb_sec(x), y).item())
            model_to_be_saved = copy.deepcopy(model_perb_sec).eval()
            # compute the accuracy, recall, precision, f1 score and confusion matrix of the perb model
            preds = model_to_be_saved(x)
            # get the accuracy
            accuracy = Accuracy(subset_accuracy=True)
            model_accuracy.append(accuracy(preds, y))
            # get the recall
            recall = Recall(average='macro', num_classes=10)
            model_recall.append(recall(preds, y))
            # get the precision
            precision = Precision(average='macro', num_classes=10)
            model_precision.append(precision(preds, y))
            # get the f1 score
            f1 = F1Score(num_classes=10)
            model_f1.append(f1(preds, y))
            # get the confusion matrix
            confusionMatrix = ConfusionMatrix(num_classes=10)
            model_confusionMatrix.append(confusionMatrix(preds, y))
            model_list_sec.append(model_to_be_saved)
        loss_list.append(loss_list_sec)
        model_list.append(model_list_sec)

    # generate the result string
    result_array = np.array(loss_list)
    result_string = np.array2string(result_array, precision=4, separator=',', suppress_small=True)
    result_string = ""
    for i in range(len(loss_list)):
        for j in range (len(loss_list[i])):
            if (i != STEPS-1 or j != STEPS-1):
                result_string += str(loss_list[i][j]) + ","
            else:
                result_string += str(loss_list[i][j])
    
    return top_eigenvalues, result_string, model_list, model_accuracy, model_recall, model_precision, model_f1, model_confusionMatrix
```

## Random Projection Loss Landscapes
Besides the hessian parametric loss landscapes, we also provide one way to generate the classic loss landscapes for different models and compare the similarity among them using random projection method. The method to generate the classic loss landscapes has already merged into the main calculation function. It is calculated by the following function:

```python
def calculate_loss_landscapes_random_projection(dataset, subdataset_list, criterion, x, y, IN_DIM, OUT_DIM, STEPS):
    # prepare the result list
    loss_data_fin_list = []
    max_loss_value_list = []
    min_loss_value_list = []
    
    # prepare all the models
    model_list = get_model_list(dataset, subdataset_list, IN_DIM, OUT_DIM)
    
    # calculate the first original sub-dataset and get one random projection
    metric = loss_landscapes.metrics.Loss(criterion, x, y)
    
    # calculate the loss landscape in 2 dimensions for the first model
    loss_data_fin, dir_one, dir_two = loss_landscapes.random_plane(model_list[0], metric, 10, STEPS, normalization='filter', deepcopy_model=True)
    loss_data_fin_list.append(loss_data_fin)
    
    # first array corresponds to which row, and the latter corresponds to which column
    max_loss = np.where(loss_data_fin == np.max(loss_data_fin))
    max_loss_value_list.append(max_loss[0][0])
    max_loss_value_list.append(max_loss[1][0])
    min_loss = np.where(loss_data_fin == np.min(loss_data_fin))
    min_loss_value_list.append(min_loss[0][0])
    min_loss_value_list.append(min_loss[1][0])
    
    # calculate the loss landscape in 2 dimensions for the rest of the models
    for i in range(1, len(model_list)):
        # calculate the loss landscape in 2 dimensions for the model
        loss_data_fin_this = loss_landscapes.random_plane_given_plane(model_list[i], metric, dir_one, dir_two, 10, STEPS, normalization='filter', deepcopy_model=True)
        loss_data_fin_list.append(loss_data_fin_this)
        
        # first array corresponds to which row, and the latter corresponds to which column
        max_loss_this = np.where(loss_data_fin_this == np.max(loss_data_fin_this))
        max_loss_value_list.append(max_loss_this[0][0])
        max_loss_value_list.append(max_loss_this[1][0])
        min_loss_this = np.where(loss_data_fin_this == np.min(loss_data_fin_this))
        min_loss_value_list.append(min_loss_this[0][0])
        min_loss_value_list.append(min_loss_this[1][0])
        
    return loss_data_fin_list, max_loss_value_list, min_loss_value_list
```

All the results will be saved in the MongoDB and all the generated binary files used for ttk will be saved under the `ttk/input_binary_for_ttk` folder. The loss landscapes information stored in the MongoDB can be requested by the Front-End. In the Front-End, this information can be plotted as several 2D and 3D loss landscapes plots.